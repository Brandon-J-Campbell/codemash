0. Get your test suite running
  a. npm run test-module-1
  b. You should see this test output (show)

1. Test - "it builds a greeting" (M! template literals)
  a. Uncomment test
  b. Test fails!
  c. Write with concatenation
  d. Write with string template literal

2. Test - "it chooses a parting word" (N! ternary)
  a. Uncomment test
  b. Test fails!
  c. Write with if statement
  d. Write with ternary

3. Test - "it chooses a parting word with destructuring" (O! destructuring)
  a. Uncomment test
  b. Test fails!
  c. Write with manual property assignment
  d. Write with destructuring in the body
  e. Write with destructuring in arguments

4. Test - "it maps parting words" (P! array.map)
  a. Uncomment test
  b. Test fails!
  c. Write with looping
  d. Write with array.map
