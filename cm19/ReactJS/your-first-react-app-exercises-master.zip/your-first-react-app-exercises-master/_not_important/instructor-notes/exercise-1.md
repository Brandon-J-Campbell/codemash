-1. get latest
  a. git checkout master
  b. git pull

0. Get your test suite running
  a. npm run test-module-1
  b. You should see this test output (show)

1. Write a test of our `add` function.
  a. Uncomment the test (in ./add.spec.js) (A!)
  b. Import the `add` function (as a named import) (B!)
  c. Mark the `add` function as a named export (C!)
  d. Convert test to fat-arrow

2. Write a test of our `addThree` function.
  a. Uncomment the test in ./add.spec.js (A!)
  b. Import the `addThree` function (as a default import) (D!)
  c. Mark the `addThree` function as a default export (E!)
  d. Rename the `addThree` function

3. Show an import from npm (F!)
