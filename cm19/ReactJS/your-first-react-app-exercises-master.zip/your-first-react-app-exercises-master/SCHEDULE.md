# Agenda:

## Morning

### Setup

### About

### History

### React

### JavaScript

### Components

### Components + React

### Components + React + JSX

9:55 - 10:15

#### Ex 6: render Results

10:23-10:40 (15-20 min)

#### Ex 7: Convert a component

10:50-11:00 (10 min)

### Props

#### Ex. 8: Composition/props.children

11:10-??

#### Ex. 9: prop types

SKIP THIS!!!
this took me up to 11:45

## Lunch!

## After lunch:

Starting at 1:00

### CSS

### Routing

#### Ex 12: React Router

1:40-1:55 (15 min)

### State (15 min)

#### Ex 13: Managing Component State

2:10-2:30 (20 min)

### Break (10)

### Events (5 min)

#### Ex 14: Async/Await (10 min)

### Lifecycle (5 min)

#### Ex 15: Loading Data

2:55-3:15 (20 min)

### App State

#### Ex 16: React Context

3:25-3:45 TALKING ONLY (20 min)

### Break (5-10)

### Testing

3:55-4:05

#### Ex 17: Testing Render

4:05-4:20

#### Ex 18: Testing Interactions

4:22-4:40

### Good Practices/Questions
