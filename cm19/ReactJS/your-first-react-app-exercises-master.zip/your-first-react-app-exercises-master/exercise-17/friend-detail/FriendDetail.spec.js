import React from 'react';

import { MemoryRouter } from 'react-router-dom';
import ThemeProvider from '../theme/Provider';

import { render } from 'react-testing-library';

import FriendDetail from './FriendDetail';

describe('./friend-detail/FriendDetail', () => {

  it('renders loading if friend isn`t loaded yet', () => {
    // arrange

    // act

    // assert
  });

  it('renders a friend if friend is loaded', () => {
    // arrange

    // act

    // assert
  });
});
