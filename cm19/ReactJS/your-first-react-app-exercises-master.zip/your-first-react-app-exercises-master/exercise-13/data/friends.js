export default [
  {
    id: 1,
    name: 'Potatoes',
    image: 'http://placekitten.com/150/150?image=1',
    bio: 'This soft little kitten loves to play in window sills, and snuggles like a champion.',
    colors: [ 'Gray', 'Black' ]
  },
  {
    id: 2,
    name: 'Flower',
    image: 'http://placekitten.com/150/150?image=12',
    bio: 'This teensy little girl is a sweetheart. Her tiny baby sneezes will warm your heart.',
    colors: [ 'Gray', 'Black', 'White' ]
  },
  {
    id: 3,
    name: 'Turtle',
    image: 'http://placekitten.com/150/150?image=15',
    bio: 'This old pal loves to leap for flying toy mice. Throw anything his way, and he\'ll impress you with some backflips.',
    colors: [ 'Gray', 'White' ]
  },
];
