const React = require('react');

if (React !== undefined) {
  console.log('You\'re all set!');
} else {
  console.log('Something\'s not right.');
}
