# Possible Solutions

## Component CSS Files

### App.css
```css
.App {
  text-align: center;
}

.App-header {
  background-color: teal;
  height: 100px;
  padding: 20px;
  color: white;
}

.App-title {
  font-family: 'Pacifico', cursive;
  line-height: 0.5em;
}

.App-intro {
  font-size: large;
}
```

### Card.css
```css
.card {
  min-width: 150px;
  background-color: mintcream;
  margin: 20px;
  padding: 30px;
  box-shadow: 0 1px 2px teal;
}

.card:hover {
  box-shadow: 0 2px 4px teal;
}
```

### FriendProfile.css
```css
.friend-profile {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.friend-profile h3 {
  margin-bottom: 0;
}
```

### Page.css
```css
.page {
  display: flex;
  flex-direction: row;
  justify-content: center;
  background: repeating-linear-gradient(to top, mintcream, teal);
  height: calc(100vh - 140px);
}

.content{
  background-color: white;
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: flex-start;
  height: calc(100vh - 140px);
  width: 1000px;
}
```
