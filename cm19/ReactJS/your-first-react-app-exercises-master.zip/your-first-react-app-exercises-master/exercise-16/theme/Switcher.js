import React from 'react';

import styles from './Switcher.css';

export default function() {
  return <button className={styles.switcher}>Change Theme</button>;
}
