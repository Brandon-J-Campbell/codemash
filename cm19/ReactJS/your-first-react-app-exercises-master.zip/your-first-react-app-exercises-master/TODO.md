Hooks/effects
✅ Modify code
Write up instructions
Capture SOLUTIONS.md

Find a place to mention array destructuring

Prop Types:

- remove exercise
- Talk only

Context:

- leave exercise
- Talk only

Add a slight delay to the API so you can see loading

- there is a setting in json-server for this
- `--delay 500`

Ex 10 (Component CSS files):

- make it just about looking around.
- Make CSS just a talk????
- Add StyledComponents examples to also look around?

Add time for 20 minutes? of questions at the end

Talk about forms?
