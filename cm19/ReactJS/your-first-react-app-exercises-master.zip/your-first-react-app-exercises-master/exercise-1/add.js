function add(a, b) {
  return a + b;
}

function addThree(a) {
  return add(a, 3);
}
