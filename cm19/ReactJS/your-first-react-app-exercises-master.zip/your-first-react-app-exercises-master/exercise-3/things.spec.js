import { ThingOne, ThingTwo } from './things';

// 1: Uncomment the next 8 lines for test 1.
// it('is a thing', () => {
//   //  To "instantiate" a class, call `new ClassName()`. 
//   //   We won't be doing very much of this, if any. 
//   //   React will take care of this for us, behind the scenes.
//   const thing = new ThingOne();

//   expect(thing).not.toBeUndefined();
// })




// 2: Uncomment the next 8 for test 2.
// it('inherits base properties', () => {
//   const thingTwo = new ThingTwo();

//   //  Since ThingOne extends Thing, we get both properties
//   //   on our instance of thingOne.
//   expect(thingTwo.thingTwoProperty).toEqual(2);
//   expect(thingTwo.thingOneProperty).toEqual(1);
// })




// 3: Uncomment the next 6 lines for test 3.
// it('adds it up', () => {
//   const thingTwo = new ThingTwo();

//   //  Here we're calling an instance method.
//   expect(thingTwo.addItUp()).toEqual(3);
// });
