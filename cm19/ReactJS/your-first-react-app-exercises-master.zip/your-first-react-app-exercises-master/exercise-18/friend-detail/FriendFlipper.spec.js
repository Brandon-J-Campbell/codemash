import React from 'react';
import { render, fireEvent } from 'react-testing-library';
import { MemoryRouter } from 'react-router-dom';
import ThemeProvider from '../theme/Provider';

import FriendFlipper from './FriendFlipper';

describe('./friend-detail/FriendFlipper', () => {
  it('defaults to the front side', () => {
    // arrange

    // act

    // assert
  });

  it('flips to the back side after a button click', () => {
    // arrange

    // act

    // assert
  });
});
