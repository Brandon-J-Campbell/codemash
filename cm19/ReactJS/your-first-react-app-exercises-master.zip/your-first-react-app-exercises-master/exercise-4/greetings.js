
export function buildGreeting(name) {
}

export function choosePartingWord(language) {
}

export function choosePartingWordFromObject(data) {
}

export function mapPartingWords(languages) {
}
